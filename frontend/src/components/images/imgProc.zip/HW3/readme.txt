ImageProcessing HW3 by Yuval Avitan - 319066007, Vicky Hlustov 320755481

ImageProcessingHW3.py is a CLI script, you can use it by cmd in the following way:

>python main.py .\hhd_dataset 

Script follows the following steps:
	1. Creates array with all the images by letters.
	2. Converts the images to grayscale. and resize
	3. Performs binarization on the images.
	4. Resizing the images to 32X32.
	5. Adds white padding to images.
	6. Dividing the images into 3 sets (training, validation, testing).
	7. Trains the classifier with different values of k and finds the best k.
	8.   Creates text file that contains best k and accuracy.
	9.   Creates csv file with confusion matrix.

Used libraries:
os
cv2
numpy
sklearn