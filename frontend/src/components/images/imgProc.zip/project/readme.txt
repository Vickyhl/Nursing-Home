ImageProcessing finalProject by Yuval Avitan - 319066007, Vicky Hlustov 320755481

Gender Classification from Handwriting is a CLI script, you can use it by cmd in the following way:

> python classifier.py path_train path_val path_test 

Script follows the following steps:
	1. Loads the stock that contains test, valid and train folders.
	2. Performs feature extraction.
	3. Performing training with different values of radius, points and kernels:
		3.1. Trains with linear kernel.
		3.2. Trains with RBF kernel.

	4. Finds the best combination of accuracy on validation set.
	5. Evaluating the SVM on test set and reports the results.

Used libraries:
os
cv2
sys
numpy 
skimage 