ImageProcessing HW2 by Yuval Avitan - 319066007, Vicky Hlustov 320755481

ImageProcessingHW2.py is a CLI script, you can use it by cmd in the following way:

>python main.py input_image_path output_image_path 

Script follows the following steps:
	1. applyes binarization on the input image.
	2. Finds image contours of the binarized image.
	3. Sorts the contours to find the biggest one.
	4. Sorts points by x value, meaning first 2 elements of list are the left points.
	5. Calculates h,w of output image by averaging heights and widths of both of heights and widths accordingly.
	6. Creates a transform matrix from discovered points to a (h,w) shape image.
	7. Applyes the transform matrix to create the aligned image.
	
Used libraries:
cv2
sys
numpy