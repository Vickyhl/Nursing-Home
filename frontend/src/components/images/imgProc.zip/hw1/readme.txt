The readme.txt should include the following information:
 
* The authors' contact information

* Description
A brief description of your program. 

* Environment

Describe the OS and compilation requirements needed to compile and run the program

* How to Run Your Program

Provide instructions and examples so users how to run the program. 
Describe if there are any assumptions on the input.
You can also include screenshots to show examples.